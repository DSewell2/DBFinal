import React, { useEffect } from 'react'

function App() {
  const [data, setData] = useState([])
  useEffect(()=> {
    fetch('http://localhost:8081/users')
    .then(res => res.json())
    .then(data => console.log(data))
    .catch(Err => console.log(err));
  }, [])

  return (
    <div style = {{padding: "50px"}}>
      <thead>
        <th>ID</th>
        <th>Name</th>
        <th>Phone</th>
        <th>Email</th>
      </thead>
      <tbody>
        {data.map((d, i) => (
          <tr key = {i}>
            <td>{d.id}</td>
            <td>{d.name}</td>
            <td>{d.mobile}</td>
            <td>{d.email}</td>
          </tr>
        ))}
      </tbody>
    </div>
  )
}

export default App